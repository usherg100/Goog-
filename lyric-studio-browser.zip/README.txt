LYRIC.STUDIO — browser version

This is a client-side website: audio, images/video, lyrics and export stay in the browser.

To put it online for free:
1. Create a GitHub repository.
2. Upload index.html.
3. In Settings > Pages, choose Deploy from branch, then main / root.
4. GitHub will give you a normal https://... URL that works on iPhone and desktop.

The site does not require a server or API for its editor.
